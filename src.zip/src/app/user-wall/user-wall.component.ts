import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-wall',
  templateUrl: './user-wall.component.html',
  styleUrls: ['./user-wall.component.css']
})
export class UserWallComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}